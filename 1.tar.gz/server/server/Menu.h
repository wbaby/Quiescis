/*
 * Displaying a menu about RAT commands
 * Banner output
*/

#ifndef MENU_H
#define MENU_H

void timenow();
void HelpMenu();
void PrintGreeting();

#endif
