/*
 * Server side
 * Socket definition
*/

#ifndef SOCKET_H
#define SOCKET_H

SOCKADDR_IN Server();

#endif // SOCKET_H
